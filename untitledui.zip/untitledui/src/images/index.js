import logo from "./logo.png";
import zap from "./zap.svg";
import staked from "./staked.png";
import withdrawn from "./withdrawn.png";
import rewards from "./rewards.png";
import sheild from "./shield.png";
export { logo, zap, staked, withdrawn, rewards, sheild };
